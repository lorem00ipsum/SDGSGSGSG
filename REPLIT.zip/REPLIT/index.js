const { Client, GatewayIntentBits, PermissionsBitField, EmbedBuilder, Events } = require("discord.js");
const { QuickDB } = require("quick.db");
const db = new QuickDB();
const express = require("express");

// ======================
// EXPRESS pour Render / Replit
// ======================
const app = express();
const PORT = process.env.PORT || 3000;
app.get("/", (req, res) => res.send("Bot is running!"));
app.listen(PORT, () => console.log(`Web server started on port ${PORT}`));

// ======================
// Discord Client
// ======================
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers
  ]
});

// ======================
// CONFIG
// ======================
const TOKEN = "MTQ3MTIxMTMyMjA3NDA3NTMwNg.G4AFi-.n3TxbpCHHpNLecWKqw37dTn9tY2ixUriR342qc"; // ton token
const ranks = ["Bronze","Silver","Gold","Platinum","Diamond","Champion","Unreal"];
const practiceLevels = ["Debutant","Intermediaire","Avance","Pro"];
const XP_PER_MESSAGE = 5;
const MUTE_DURATION = 5; // minutes par défaut
const SPAM_THRESHOLD = 5; // messages par 10 secondes

// ======================
// Anti-Spam
// ======================
const userMessages = {};

// ======================
// Bot Ready
// ======================
client.once(Events.ClientReady, () => {
  console.log(`🔥 Deaxty Bot connecté en tant que ${client.user.tag}`);
});

// ======================
// Leveling automatique
// ======================
client.on("messageCreate", async message => {
  if (message.author.bot) return;

  // Anti-spam simple
  if (!userMessages[message.author.id]) userMessages[message.author.id] = [];
  userMessages[message.author.id].push(Date.now());
  userMessages[message.author.id] = userMessages[message.author.id].filter(ts => Date.now() - ts < 10000);
  if (userMessages[message.author.id].length > SPAM_THRESHOLD) {
    let muteRole = message.guild.roles.cache.find(r => r.name === "Muted");
    if (!muteRole) muteRole = await message.guild.roles.create({ name: "Muted", permissions: [] });
    const member = await message.guild.members.fetch(message.author.id);
    await member.roles.add(muteRole);
    await db.set(`mute_${member.id}`, Date.now() + MUTE_DURATION*60000);
    message.channel.send(`🔇 ${member.user.tag} a été mute automatiquement pour spam.`);
    return;
  }

  // Leveling
  await db.add(`xp_${message.author.id}`, XP_PER_MESSAGE);
  const xp = await db.get(`xp_${message.author.id}`);
  const level = Math.floor(Math.sqrt(xp/10));
  const oldLevel = await db.get(`level_${message.author.id}`) || 0;
  if (level > oldLevel) {
    await db.set(`level_${message.author.id}`, level);
    message.channel.send(`🎉 ${message.author.tag} a atteint le niveau ${level} !`);
  }
});

// ======================
// Interaction Create (Commandes Slash)
// ======================
client.on(Events.InteractionCreate, async interaction => {
  if (!interaction.isChatInputCommand()) return;
  await interaction.deferReply({ ephemeral: false });

  try {
    const { commandName } = interaction;

    // =====================
    // MODERATION
    // =====================
    if (commandName === "ban") {
      if (!interaction.member.permissions.has(PermissionsBitField.Flags.BanMembers))
        return await interaction.editReply("❌ Permission refusée");
      const user = interaction.options.getUser("user");
      await interaction.guild.members.ban(user);
      return await interaction.editReply(`🔨 ${user.tag} a été banni.`);
    }

    if (commandName === "kick") {
      if (!interaction.member.permissions.has(PermissionsBitField.Flags.KickMembers))
        return await interaction.editReply("❌ Permission refusée");
      const member = interaction.options.getMember("user");
      await member.kick();
      return await interaction.editReply(`👢 ${member.user.tag} a été kick.`);
    }

    if (commandName === "clear") {
      const amount = interaction.options.getInteger("amount");
      await interaction.channel.bulkDelete(amount);
      return await interaction.editReply(`🧹 ${amount} messages supprimés.`);
    }

    // =====================
    // MUTE / UNMUTE
    // =====================
    if (commandName === "mute") {
      if (!interaction.member.permissions.has(PermissionsBitField.Flags.MuteMembers))
        return await interaction.editReply("❌ Permission refusée");
      const member = interaction.options.getMember("user");
      const duration = interaction.options.getInteger("duration") || MUTE_DURATION;
      let muteRole = interaction.guild.roles.cache.find(r => r.name === "Muted");
      if (!muteRole) muteRole = await interaction.guild.roles.create({ name: "Muted", permissions: [] });
      await member.roles.add(muteRole);
      await db.set(`mute_${member.id}`, Date.now() + duration*60000);
      return await interaction.editReply(`🔇 ${member.user.tag} est mute pour ${duration} minutes.`);
    }

    if (commandName === "unmute") {
      const member = interaction.options.getMember("user");
      let muteRole = interaction.guild.roles.cache.find(r => r.name === "Muted");
      if (muteRole) await member.roles.remove(muteRole);
      await db.delete(`mute_${member.id}`);
      return await interaction.editReply(`🔊 ${member.user.tag} est unmute.`);
    }

    // =====================
    // WARNS
    // =====================
    if (commandName === "warn") {
      if (!interaction.member.permissions.has(PermissionsBitField.Flags.KickMembers))
        return await interaction.editReply("❌ Permission refusée");
      const user = interaction.options.getUser("user");
      const reason = interaction.options.getString("reason") || "Non spécifiée";
      let warns = await db.get(`warns_${user.id}`) || [];
      warns.push({ reason, date: new Date().toISOString(), mod: interaction.user.tag });
      await db.set(`warns_${user.id}`, warns);
      return await interaction.editReply(`⚠️ ${user.tag} a été averti. Raison: ${reason}`);
    }

    if (commandName === "warns") {
      const user = interaction.options.getUser("user") || interaction.user;
      const warns = await db.get(`warns_${user.id}`) || [];
      const embed = new EmbedBuilder()
        .setTitle(`⚠️ Warns de ${user.tag}`)
        .setColor("Red")
        .setDescription(warns.length ? warns.map((w,i)=>`${i+1}. ${w.reason} par ${w.mod} le ${w.date}`).join("\n") : "Aucun warn");
      return await interaction.editReply({ embeds: [embed] });
    }

    // =====================
    // RANK SYSTEM
    // =====================
    if (commandName === "setrank") {
      if (!interaction.member.permissions.has(PermissionsBitField.Flags.ManageRoles))
        return await interaction.editReply("❌ Permission refusée");
      const user = interaction.options.getUser("user");
      const rank = interaction.options.getString("rank");
      if (!ranks.includes(rank)) return await interaction.editReply("❌ Rank invalide");
      await db.set(`rank_${user.id}`, rank);
      let role = interaction.guild.roles.cache.find(r => r.name === rank);
      if (!role) role = await interaction.guild.roles.create({ name: rank });
      const member = await interaction.guild.members.fetch(user.id);
      await member.roles.add(role);
      return await interaction.editReply(`🏆 ${user.tag} est maintenant ${rank}`);
    }

    // =====================
    // PRACTICE SYSTEM
    // =====================
    if (commandName === "practice") {
      const user = interaction.options.getUser("user");
      const level = interaction.options.getString("level");
      if (!practiceLevels.includes(level)) return await interaction.editReply("❌ Niveau invalide");
      await db.set(`practice_${user.id}`, level);
      let role = interaction.guild.roles.cache.find(r => r.name === level);
      if (!role) role = await interaction.guild.roles.create({ name: level });
      const member = await interaction.guild.members.fetch(user.id);
      await member.roles.add(role);
      return await interaction.editReply(`🎯 ${user.tag} est maintenant niveau ${level}`);
    }

    // =====================
    // POINTS + LEADERBOARD
    // =====================
    if (commandName === "addpoints") {
      const user = interaction.options.getUser("user");
      const pts = interaction.options.getInteger("points");
      await db.add(`points_${user.id}`, pts);
      return await interaction.editReply(`➕ ${pts} points ajoutés à ${user.tag}`);
    }

    if (commandName === "profile") {
      const user = interaction.options.getUser("user") || interaction.user;
      const rank = await db.get(`rank_${user.id}`) || "Non classé";
      const practice = await db.get(`practice_${user.id}`) || "Non défini";
      const points = await db.get(`points_${user.id}`) || 0;
      const level = await db.get(`level_${user.id}`) || 0;
      const embed = new EmbedBuilder()
        .setTitle(`🎮 Profil Fortnite`)
        .addFields(
          { name: "Rank", value: rank, inline: true },
          { name: "Practice", value: practice, inline: true },
          { name: "Points", value: points.toString(), inline: true },
          { name: "Level", value: level.toString(), inline: true }
        ).setColor("Blue");
      return await interaction.editReply({ embeds: [embed] });
    }

    if (commandName === "leaderboard") {
      const allKeys = await db.all();
      const pointsKeys = allKeys.filter(k=>k.id.startsWith("points_"));
      const leaderboard = pointsKeys
        .map(k=>({ id: k.id.replace("points_",""), pts: k.value }))
        .sort((a,b)=>b.pts - a.pts)
        .slice(0,10);
      const embed = new EmbedBuilder()
        .setTitle("🏆 Leaderboard")
        .setColor("Gold")
        .setDescription(leaderboard.map((u,i)=>`${i+1}. <@${u.id}> - ${u.pts} points`).join("\n") || "Aucun joueur");
      return await interaction.editReply({ embeds: [embed] });
    }

    // =====================
    // PARTIES PRIVÉES
    // =====================
    if (commandName === "createparty") {
      const code = Math.random().toString(36).substring(2,8).toUpperCase();
      await db.set(`party_${code}`, [interaction.user.id]);
      return await interaction.editReply(`🎮 Partie privée créée ! Code : \`${code}\``);
    }

    if (commandName === "joinparty") {
      const code = interaction.options.getString("code");
      let party = await db.get(`party_${code}`);
      if (!party) return await interaction.editReply("❌ Partie inexistante");
      party.push(interaction.user.id);
      await db.set(`party_${code}`, party);
      return await interaction.editReply(`✅ Tu as rejoint la partie \`${code}\``);
    }

    // =====================
    // ANNOUNCE / REMINDER
    // =====================
    if (commandName === "announce") {
      if (!interaction.member.permissions.has(PermissionsBitField.Flags.ManageGuild))
        return await interaction.editReply("❌ Permission refusée");
      const channel = interaction.options.getChannel("channel");
      const messageText = interaction.options.getString("message");
      await channel.send(`📢 Annonce : ${messageText}`);
      return await interaction.editReply("✅ Annonce envoyée");
    }

  } catch (err) {
    console.error(err);
    if (!interaction.replied) await interaction.editReply("❌ Une erreur est survenue.");
  }
});

// ======================
// Lancement du bot
// ======================
client.login(TOKEN);
